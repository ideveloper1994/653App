//
//  TodayViewController.m
//  TodayScreenWidgetExtension
//
//  Created on 26/10/18.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import "TodayViewController.h"
#import <NotificationCenter/NotificationCenter.h>

@interface TodayViewController () <NCWidgetProviding>

@end

@implementation TodayViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view from its nib.
  
}

- (void)widgetPerformUpdateWithCompletionHandler:(void (^)(NCUpdateResult))completionHandler {
  // Perform any setup necessary in order to update the view.
  
  // If an error is encountered, use NCUpdateResultFailed
  // If there's no update required, use NCUpdateResultNoData
  // If there's an update, use NCUpdateResultNewData
  NSString *groupName = @"group.com.ausappstudio.brainbuddy.TodayScreenWidgetExtension";
  NSUserDefaults *sharedDefaults = [[NSUserDefaults standardUserDefaults] initWithSuiteName:groupName];
  
  if([sharedDefaults valueForKey:@"isLogin"] != nil){
    NSString *val = [sharedDefaults valueForKey:@"isLogin"];
    if([val isEqualToString:@"NO"]){
      [[self mainView]setHidden:YES];
      [[self lblNoData]setHidden:NO];
    }else{
      [[self mainView]setHidden:NO];
      [[self lblNoData]setHidden:YES];
      if([sharedDefaults valueForKey:@"bestStreak"] != nil){
        NSString *val = [sharedDefaults valueForKey:@"bestStreak"];
        [[self lblBest]setText:val];
      }
      
      if([sharedDefaults valueForKey:@"currentClean"] != nil){
        NSString *val = [sharedDefaults valueForKey:@"currentClean"];
        [[self lblStreak]setText:val];
      }
      
      if([sharedDefaults valueForKey:@"goalDescription"] != nil){
        NSString *val = [sharedDefaults valueForKey:@"goalDescription"];
        [[self lblGoal]setText:val];
      }
      
      if([sharedDefaults valueForKey:@"totalDays"] != nil){
        NSString *val = [sharedDefaults valueForKey:@"totalDays"];
        [[self lblTotal]setText:val];
      }
      if([sharedDefaults valueForKey:@"currentPer"] != nil){
        double currentPer = [[sharedDefaults valueForKey:@"currentPer"]doubleValue];
        double val = [[UIScreen mainScreen] bounds].size.width - 80; //40 constrain let and right
        int finalVal = val - (currentPer*val)/100;
        [[self rightConstant] setConstant:-finalVal];
      }
    }
  }else{
    [[self mainView]setHidden:YES];
    [[self lblNoData]setHidden:NO];
  }
  [sharedDefaults synchronize];
  completionHandler(NCUpdateResultNewData);
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

- (void)widgetActiveDisplayModeDidChange:(NCWidgetDisplayMode)activeDisplayMode
                         withMaximumSize:(CGSize)maxSize {
  
  //  if(activeDisplayMode == NCWidgetDisplayModeCompact){
  //    self.preferredContentSize = CGSizeMake(maxSize.width, 500);
  //  }else{
  //    self.preferredContentSize = CGSizeMake(maxSize.width, 300);
  //  }
  
}
@end
