//
//  TodayViewController.h
//  TodayScreenWidgetExtension
//
//  Created on 26/10/18.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TodayViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblGoal;
@property (weak, nonatomic) IBOutlet UILabel *lblTotal;
@property (weak, nonatomic) IBOutlet UILabel *lblBest;
@property (weak, nonatomic) IBOutlet UILabel *lblStreak;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rightConstant;
@property (weak, nonatomic) IBOutlet UIView *mainView;
@property (weak, nonatomic) IBOutlet UILabel *lblNoData;

@end
