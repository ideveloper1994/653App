//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created on 23/04/18.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
