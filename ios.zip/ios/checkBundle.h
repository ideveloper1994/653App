
#import <UIKit/UIKit.h>
#import <React/RCTBridgeModule.h>
#import <React/RCTLog.h>

@interface checkBundle : NSObject <RCTBridgeModule>

@end
