#import <UIKit/UIKit.h>
#import <AVKit/AVKit.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface avplayerViewController : AVPlayerViewController

@end
