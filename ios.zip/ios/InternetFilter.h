//
//  InternetFilter.h
//  BrainBuddyReact
//
//  Created on 30/03/18.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <React/RCTBridgeModule.h>
# import <React/RCTLog.h>

@interface InternetFilter : NSObject <RCTBridgeModule>

@end
