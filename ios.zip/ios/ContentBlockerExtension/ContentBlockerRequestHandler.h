//
//  ContentBlockerRequestHandler.h
//  ContentBlockerExtension
//
//  Created on 29/03/18.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContentBlockerRequestHandler : NSObject <NSExtensionRequestHandling>

@end
